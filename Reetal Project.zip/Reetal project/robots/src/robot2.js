function Robot2()
{
    return(
        <div id="Robot2Page">
            This is robot2's page
        </div>
    )
}

export default Robot2;