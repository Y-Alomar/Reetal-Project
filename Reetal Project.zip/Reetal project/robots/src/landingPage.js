function Landing()
{
    return(
        <div id="landing">
            Landing page
        </div>
    )
}

export default Landing;