import { useNavigate } from 'react-router-dom';

function Header()
{
    const navigate = useNavigate(); 

    const handleRobot1Click = () => {
        navigate('/robot1'); 
    };

    const handleTitleClick = () =>{
        navigate('/landing');
    };


    const handleRobot2Click = () => {
        navigate('/robot2');
    };
    return(
        <div id="header">
            <div id="robot1" onClick={handleRobot1Click}>
                Robot1
            </div>
            <div id="title" onClick={handleTitleClick}>
                Title
            </div>
            <div id="robot2" onClick={handleRobot2Click}>
                Robot2
            </div>







        </div>
    )
}

export default Header;