function Robot1()
{


    return(
        <div id="Robot1Page">
            This is robot1's page
        </div>
    )
}

export default Robot1;