import './App.css';
import { BrowserRouter as Router, Routes, Route,useNavigate } from 'react-router-dom';
import Header from './header';
import Landing from './landingPage';
import Robot1 from './robot1';
import Robot2 from './robot2';


function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/landing" element={<Landing />} />
          <Route path="/robot1" element={<Robot1 />} />
          <Route path="/robot2" element={<Robot2 />} />

        </Routes>
      </Router>
      
      
      
      
      
    </div>
  );
}

export default App;
